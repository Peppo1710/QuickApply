const { google } = require('googleapis');
const UserProfile = require('../models/UserProfile');

/**
 * Sends the application email using Gmail API.
 * @param {Object} params
 * @param {string} params.to - Recipient email.
 * @param {string} params.subject - Email subject.
 * @param {string} params.bodyHtml - Email body in HTML.
 * @param {Object} params.userProfile - User profile for "From" and links.
 */
const sendApplicationEmail = async ({ to, subject, bodyHtml, userProfile }) => {
    try {
        // Get user's Google OAuth tokens
        const user = await UserProfile.findById(userProfile._id || userProfile.id);
        
        if (!user || !user.googleAccessToken) {
            throw new Error('User not authenticated with Google. Please log in with Google to send emails.');
        }

        // TEST MODE: Skip actual email sending
        if (process.env.TEST_MODE === 'true') {
            console.log('\n=== TEST MODE: Email NOT sent ===');
            console.log('To:', to);
            console.log('Subject:', subject);
            console.log('From:', userProfile.fullName);
            console.log('Reply-To:', userProfile.email);
            console.log('Body Preview:', bodyHtml.substring(0, 200) + '...');
            console.log('=================================\n');
            return;
        }

        // Set up OAuth2 client
        const oauth2Client = new google.auth.OAuth2(
            process.env.CLIENT_ID,
            process.env.CLIENT_SECRET,
            process.env.BACKEND_URL ? `${process.env.BACKEND_URL}/oauth/callback` : 'http://localhost:3000/oauth/callback'
        );

        oauth2Client.setCredentials({
            access_token: user.googleAccessToken,
            refresh_token: user.googleRefreshToken
        });

        // Refresh token if needed
        try {
            await oauth2Client.getAccessToken();
        } catch (error) {
            // If token refresh fails, try to refresh it
            if (user.googleRefreshToken) {
                const { credentials } = await oauth2Client.refreshAccessToken();
                user.googleAccessToken = credentials.access_token;
                if (credentials.refresh_token) {
                    user.googleRefreshToken = credentials.refresh_token;
                }
                await user.save();
                oauth2Client.setCredentials({
                    access_token: user.googleAccessToken,
                    refresh_token: user.googleRefreshToken
                });
            } else {
                throw new Error('Google OAuth token expired. Please log in again with Google.');
            }
        }

        // Create Gmail API client
        const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

        // Append links to the body
        const linksHtml = `
            <br><hr>
            <p><strong>My Links:</strong></p>
            <ul>
                ${userProfile.resumeUrl ? `<li><a href="${userProfile.resumeUrl}">Resume</a></li>` : ''}
                ${userProfile.portfolioUrl ? `<li><a href="${userProfile.portfolioUrl}">Portfolio</a></li>` : ''}
                ${userProfile.githubUrl ? `<li><a href="${userProfile.githubUrl}">GitHub</a></li>` : ''}
                ${userProfile.linkedinUrl ? `<li><a href="${userProfile.linkedinUrl}">LinkedIn</a></li>` : ''}
            </ul>
        `;

        const finalHtml = bodyHtml + linksHtml;

        // Create email message
        const emailLines = [
            `To: ${to}`,
            `From: ${userProfile.fullName} <${user.email}>`,
            `Reply-To: ${userProfile.email || user.email}`,
            `Subject: ${subject}`,
            'Content-Type: text/html; charset=utf-8',
            '',
            finalHtml
        ];

        const email = emailLines.join('\r\n');

        // Encode message in base64url format
        const encodedMessage = Buffer.from(email)
            .toString('base64')
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/, '');

        // Send email via Gmail API
        await gmail.users.messages.send({
            userId: 'me',
            requestBody: {
                raw: encodedMessage
            }
        });

        console.log(`Email sent successfully to ${to}`);
    } catch (error) {
        console.error('Gmail API Error:', error);
        throw new Error(`Failed to send email: ${error.message}`);
    }
};

module.exports = { sendApplicationEmail };
