
const axios = require('axios');

const groqApiKey = process.env.GROQ_API_KEY || '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';

if (!groqApiKey) {
    console.warn('[Quick Apply][Backend] GROQ_API_KEY is missing; using fallback email template only.');
}

/**
 * Generates a personalized job application email using Groq API directly
 */
const generateApplicationEmail = async ({ userProfile, jobPostText, detectedRole }) => {
    try {
        if (process.env.TEST_MODE === 'true') {
            return `
                <p>Dear Hiring Manager,</p>
                <p>I am writing to express my strong interest in the <strong>${detectedRole}</strong> position.</p>
                <p>As a ${userProfile.currentRole} with expertise in ${userProfile.skills}, I believe I would be a great fit for your team. ${userProfile.bio}</p>
                <p>Thank you for your consideration.</p>
                <p>Best regards,<br>${userProfile.fullName}</p>
                <p><em>--- TEST MODE (Groq API not called) ---</em></p>
            `;
        }

        if (!groqApiKey) {
            throw new Error('Groq API key not found');
        }

        const prompt = `You are a professional career assistant.
Write a very short, clear, non-spammy job application email for the user below.
Avoid buzzwords, avoid exaggerated claims, and do NOT sound like a marketing email.

User Profile:
- Name: ${userProfile.fullName}
- Current Role: ${userProfile.currentRole}
- Bio: ${userProfile.bio}
- Skills: ${userProfile.skills}

Job Details:
- Role: ${detectedRole}
- Job Post Text (may be noisy or truncated):
"""
${jobPostText.substring(0, 2000)}
"""

Instructions:
1. Subject line is NOT needed (it is added separately).
2. Return ONLY the email body in HTML using basic tags (<p>, <br>, <ul>, <li>), with no <html> or <body> wrapper.
3. Keep it compact: ideally 1–2 short paragraphs, maximum 150–180 words.
4. Briefly mention that resume and portfolio links are attached/available.
5. Use a calm, confident, respectful tone (not pushy, not salesy).
6. Naturally reference only the most relevant skills from the profile for this role.
7. Close with a simple sign-off using the user's name.`;

        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: "llama-3.1-70b-versatile",
                messages: [{ role: "user", content: prompt }],
                temperature: 0.4,
                max_tokens: 512
            },
            {
                headers: {
                    'Authorization': `Bearer ${groqApiKey}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const output = response.data.choices?.[0]?.message?.content || "";
        return output.replace(/```html|```/g, "");
    } catch (err) {
        console.error("Groq Generation Error → Falling back:", err.response?.data || err.message);
        return `
            <p>Dear Hiring Manager,</p>
            <p>I came across your opening for the <strong>${detectedRole}</strong> role and would like to be considered.</p>
            <p>I currently work as a ${userProfile.currentRole} and have experience with ${userProfile.skills}.</p>
            <p>Best regards,<br>${userProfile.fullName}</p>
        `;
    }
};

module.exports = { generateApplicationEmail };