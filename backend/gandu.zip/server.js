const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
console.log(process.env.PORT );

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const passport = require('passport');
const jwt = require('jsonwebtoken');
const profileRoutes = require('./routes/profileRoutes');
const applyRoutes = require('./routes/applyRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Debug: Verify env vars are loading (remove in production)
console.log('Environment Variables Check:');
console.log('PORT:', process.env.PORT || 'not set (using default: 3000)');
console.log('FRONTEND_URL:', process.env.FRONTEND_URL || 'not set');
console.log('JWT_SECRET:', process.env.JWT_SECRET ? '***set***' : 'not set');
console.log('CLIENT_ID:', process.env.CLIENT_ID ? '***set***' : 'not set');
console.log('CLIENT_SECRET:', process.env.CLIENT_SECRET ? '***set***' : 'not set');
console.log('GROQ_API_KEY:', process.env.GROQ_API_KEY ? '***set***' : 'not set');
console.log('BACKEND_URL:', process.env.BACKEND_URL || 'not set');
console.log('---');


// Middleware
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true
}));
app.use(express.json());
app.use(passport.initialize());

// MongoDB Connection (single-user profile, no traditional login system)
mongoose.connect('mongodb+srv://pradyumnshirsath1710:admin@truegradient.hcimnnn.mongodb.net/?appName=truegradient')
    .then(() => console.log('✅ MongoDB Connected'))
    .catch(err => console.error('❌ MongoDB Connection Error:', err));

// Routes
app.use('/api/auth', authRoutes);

// OAuth callback route (mounted separately to match Google Console callback URL: /oauth/callback)
app.get('/oauth/callback', 
    passport.authenticate('google', { session: false }),
    async (req, res) => {
        try {
            const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
            const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';
            const user = req.user;
            
            // Generate JWT token
            const token = jwt.sign(
                { userId: user._id, email: user.email },
                JWT_SECRET,
                { expiresIn: '30d' }
            );
            
            // Redirect to frontend with token
            res.redirect(`${FRONTEND_URL}/auth/callback?token=${token}`);
        } catch (error) {
            console.error('OAuth callback error:', error);
            const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';
            res.redirect(`${FRONTEND_URL}/auth/callback?error=authentication_failed`);
        }
    }
);
app.use('/api/profile', profileRoutes);
app.use('/api/apply', applyRoutes);

app.get('/api/status', (req, res) => {
    res.json({
        status: 'ok',
        mongo: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
