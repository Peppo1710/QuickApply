const express = require('express');
const router = express.Router();
const UserProfile = require('../models/UserProfile');
const authMiddleware = require('../middleware/auth');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// POST /api/profile/save - Save profile and generate JWT (no auth required)
router.post('/save', async (req, res) => {
    try {
        const profileData = req.body;

        // Find existing profile by email
        let profile = await UserProfile.findOne({ email: profileData.email.toLowerCase() });

        if (profile) {
            // Update existing profile
            Object.assign(profile, {
                ...profileData,
                email: profileData.email.toLowerCase(),
                lastUpdated: Date.now()
            });
            await profile.save();
        } else {
            // Create new profile with a default password
            const defaultPassword = await bcrypt.hash('default-password', 10);
            profile = new UserProfile({
                ...profileData,
                email: profileData.email.toLowerCase(),
                password: defaultPassword
            });
            await profile.save();
        }

        // Generate JWT
        const token = jwt.sign(
            { userId: profile._id, email: profile.email },
            JWT_SECRET,
            { expiresIn: '30d' }
        );

        const profileResponse = profile.toObject();
        delete profileResponse.password;

        res.json({
            message: 'Profile saved successfully',
            profile: profileResponse,
            token
        });
    } catch (error) {
        console.error('Error saving profile:', error);
        res.status(500).json({ error: 'Failed to save profile' });
    }
});

// PUT /api/profile/update - Update existing profile fields (auth required)
router.put('/update', authMiddleware, async (req, res) => {
    try {
        const updates = { ...req.body };
        const profile = await UserProfile.findById(req.user.userId);

        if (!profile) {
            return res.status(404).json({ error: 'Profile not found' });
        }

        if (updates.email) {
            updates.email = updates.email.toLowerCase();
        }

        Object.assign(profile, updates, { lastUpdated: Date.now() });
        await profile.save();

        const profileResponse = profile.toObject();
        delete profileResponse.password;

        res.json({
            message: 'Profile updated successfully',
            profile: profileResponse
        });
    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
});

// GET /api/profile/get - Get profile with JWT
router.get('/get', authMiddleware, async (req, res) => {
    try {
        const profile = await UserProfile.findById(req.user.userId).select('-password');

        if (!profile) {
            return res.status(404).json({ error: 'Profile not found' });
        }

        res.json(profile);
    } catch (error) {
        console.error('Error fetching profile:', error);
        res.status(500).json({ error: 'Failed to load profile' });
    }
});

// Keep old routes for backward compatibility with extension
// router.get('/', authMiddleware, async (req, res) => {
//     try {
//         const profile = await UserProfile.findById(req.user.userId).select('-password');

//         if (!profile) {
//             return res.json({});
//         }

//         res.json(profile);
//     } catch (error) {
//         console.error('Error fetching profile:', error);
//         res.status(500).json({ error: 'Failed to load profile' });
//     }
// });

module.exports = router;
