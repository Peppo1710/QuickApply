const express = require('express');
const router = express.Router();
const { generateApplicationEmail } = require('../services/geminiClient');
const { sendApplicationEmail } = require('../services/mailer');
const { extractJobDetails } = require('../services/jobParser');
const UserProfile = require('../models/UserProfile');
const axios = require('axios');
const authMiddleware = require('../middleware/auth');


const groqApiKey = process.env.GROQ_API_KEY || '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';

// Helper to get profile from DB
const getProfile = async (userId) => {
    const profile = await UserProfile.findById(userId).select('-password');
    if (!profile) {
        throw new Error('Profile not found. Please set up your profile first.');
    }
    return profile;
};

// POST /api/apply/rewrite
// New endpoint for AI rewriting
router.post('/rewrite', authMiddleware, async (req, res) => {
    try {
        const { currentEmail, prompt } = req.body;

        // TEST MODE
        if (process.env.TEST_MODE === 'true') {
            return res.json({
                rewrittenEmail: currentEmail + `\n\n[Rewritten with: "${prompt}"]`
            });
        }

        if (!groqApiKey) {
            return res.status(500).json({ error: 'Groq API key not configured' });
        }

        const aiPrompt = `You are a professional editor.
Rewrite the email below based on this instruction: "${prompt}".
Keep the HTML tags (<p>, <br>, <ul>, <li>) intact, make the message shorter and clearer, and avoid any spammy or salesy tone.

Original Email:
${currentEmail}`;

        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: "llama-3.1-70b-versatile",
                messages: [{ role: "user", content: aiPrompt }],
                temperature: 0.4,
                max_tokens: 512
            },
            {
                headers: {
                    'Authorization': `Bearer ${groqApiKey}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const content = response.data.choices?.[0]?.message?.content || "";
        const cleaned = content.replace(/```html|```/g, '');

        res.json({ rewrittenEmail: cleaned });

    } catch (error) {
        console.error('Rewrite Error:', error);
        res.status(500).json({ error: 'Failed to rewrite email' });
    }
});

// POST /api/apply
router.post('/', authMiddleware, async (req, res) => {
    try {
        const { postText, detectedEmail, detectedRole, emailBody } = req.body;
        const userProfile = await getProfile(req.user.userId);

        // If emailBody is provided (from the new extension UI), use it directly
        // Otherwise generate it (legacy flow)
        let finalEmailContent = emailBody;
        let jobDetails = { email: detectedEmail, role: detectedRole };

        if (!finalEmailContent) {
            // 1. Extract details (fill in gaps)
            jobDetails = extractJobDetails(postText, detectedEmail, detectedRole);

            if (!jobDetails.email) {
                return res.status(400).json({ error: 'No email found in job post.' });
            }

            // 2. Generate Email Content via Gemini
            finalEmailContent = await generateApplicationEmail({
                userProfile,
                jobPostText: postText,
                detectedRole: jobDetails.role
            });
        } else {
            // Ensure we have an email to send to
            if (!detectedEmail) {
                // Try to extract again if missing
                const extracted = extractJobDetails(postText, detectedEmail, detectedRole);
                jobDetails.email = extracted.email;
            }
            if (!jobDetails.email) {
                return res.status(400).json({ error: 'No email found to send to.' });
            }
        }

        // 3. Send Email
        await sendApplicationEmail({
            to: jobDetails.email,
            subject: `Application for ${jobDetails.role} - ${userProfile.fullName}`,
            bodyHtml: finalEmailContent,
            userProfile
        });

        res.json({
            success: true,
            message: `Application sent to ${jobDetails.email}`,
            generatedEmail: finalEmailContent // Return for UI to show if needed
        });

    } catch (error) {
        console.error('Apply Error:', error);
        res.status(500).json({ error: error.message || 'Failed to process application' });
    }
});

module.exports = router;
