const express = require('express');
const router = express.Router();
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const UserProfile = require('../models/UserProfile');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const CLIENT_ID = process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.CLIENT_SECRET;
console.log(CLIENT_ID)
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3000';
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

// Configure Google OAuth Strategy
if (CLIENT_ID && CLIENT_SECRET) {
    passport.use(new GoogleStrategy({
        clientID: CLIENT_ID,
        clientSecret: CLIENT_SECRET,
        callbackURL: `${BACKEND_URL}/oauth/callback`
    },
    async (accessToken, refreshToken, profile, done) => {
        try {
            // Find or create user by Google ID
            let user = await UserProfile.findOne({ googleId: profile.id });
            
            if (user) {
                // Update tokens
                user.googleAccessToken = accessToken;
                user.googleRefreshToken = refreshToken;
                await user.save();
            } else {
                // Check if user exists by email
                user = await UserProfile.findOne({ email: profile.emails[0].value.toLowerCase() });
                
                if (user) {
                    // Link Google account to existing user
                    user.googleId = profile.id;
                    user.googleAccessToken = accessToken;
                    user.googleRefreshToken = refreshToken;
                    if (!user.fullName && profile.displayName) {
                        user.fullName = profile.displayName;
                    }
                    await user.save();
                } else {
                    // Create new user
                    user = new UserProfile({
                        googleId: profile.id,
                        email: profile.emails[0].value.toLowerCase(),
                        fullName: profile.displayName || '',
                        googleAccessToken: accessToken,
                        googleRefreshToken: refreshToken,
                        currentRole: '',
                        bio: '',
                        skills: ''
                    });
                    await user.save();
                }
            }
            
            return done(null, user);
        } catch (error) {
            return done(error, null);
        }
    }));
} else {
    console.warn('[Quick Apply][Backend] Google OAuth credentials (CLIENT_ID, CLIENT_SECRET) not configured. OAuth will not work.');
}

// Serialize user for session
passport.serializeUser((user, done) => {
    done(null, user._id);
});

passport.deserializeUser(async (id, done) => {
    try {
        const user = await UserProfile.findById(id);
        done(null, user);
    } catch (error) {
        done(error, null);
    }
});

// Initiate Google OAuth
router.get('/google',
    passport.authenticate('google', {
        scope: ['profile', 'email', 'https://www.googleapis.com/auth/gmail.send']
    })
);


// Get current user (for checking auth status)
router.get('/me', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'No token provided' });
        }
        
        const token = authHeader.substring(7);
        const decoded = jwt.verify(token, JWT_SECRET);
        
        const user = await UserProfile.findById(decoded.userId).select('-password -googleAccessToken -googleRefreshToken');
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        res.json({ user, authenticated: true });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

module.exports = router;

